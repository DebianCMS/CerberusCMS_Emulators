#ifndef GLN64_TURBO3D_H
#define GLN64_TURBO3D_H

void RunTurbo3D(void);

#endif
