#ifndef GLN64_ZSORT_H
#define GLN64_ZSORT_H

void ZSort_Init(void);

#endif
