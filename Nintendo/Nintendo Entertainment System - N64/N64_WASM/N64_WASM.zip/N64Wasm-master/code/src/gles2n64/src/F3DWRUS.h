#ifndef F3DWRUS_H
#define F3DWRUS_H

#ifdef __cplusplus
extern "C" {
#endif

#define F3DWRUS_TRI2        0xB1
void F3DWRUS_Init(void);

#ifdef __cplusplus
}
#endif

#endif

