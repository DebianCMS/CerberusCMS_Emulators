#ifndef F3DEX2CBFD_H
#define F3DEX2CBFD_H

#define F3DEX2CBFD_TRI4 16

#ifdef __cplusplus
extern "C" {
#endif

void F3DEX2CBFD_Init(void);

#ifdef __cplusplus
}
#endif

#endif

