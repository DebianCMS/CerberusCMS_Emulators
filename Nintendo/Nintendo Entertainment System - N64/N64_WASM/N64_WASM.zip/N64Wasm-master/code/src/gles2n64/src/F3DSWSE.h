#ifndef F3DSWSE_H
#define F3DSWSE_H

void F3DSWSE_Init();

#endif

