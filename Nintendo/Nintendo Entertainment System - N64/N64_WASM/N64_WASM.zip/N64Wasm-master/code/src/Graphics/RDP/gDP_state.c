#include "gDP_state.h"

struct gDPInfo gDP;
